# frozen_string_literal: true

require 'rack'
require_relative 'app/admin_policy'
require_relative 'app/execution_timer'
require_relative 'app/signature'
require_relative 'app/router'

module App
  def self.init
    Rack::Builder.new do |builder|

      # map '/admin' do
      #   builder.use AdminPolicy
      # end
      # BEGIN

      # END
      # builder.use Signature

      builder.run Router.new
    end
  end
end
